package com.epam.reutska.dataprovider;


import java.util.List;

public interface IReader {
	List<String> read();
}