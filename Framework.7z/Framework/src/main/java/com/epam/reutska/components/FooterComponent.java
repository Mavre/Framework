package com.epam.reutska.components;

import org.openqa.selenium.WebDriver;


public class FooterComponent extends Component {

	public FooterComponent(WebDriver driver) {
		super(driver);
	}

}
