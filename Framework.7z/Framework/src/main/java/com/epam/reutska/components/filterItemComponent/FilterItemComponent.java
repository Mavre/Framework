package com.epam.reutska.components.filterItemComponent;

import org.openqa.selenium.WebDriver;

import com.epam.reutska.components.Component;

public class FilterItemComponent extends Component {

	public FilterItemComponent(WebDriver driver) {
		super(driver);
	}

}
