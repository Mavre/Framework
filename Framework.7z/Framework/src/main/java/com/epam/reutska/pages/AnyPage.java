package com.epam.reutska.pages;

public class AnyPage extends Page {

}
