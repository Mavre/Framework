package com.epam.reutska.components.filterItemComponent;

import org.openqa.selenium.WebDriver;


public class ProducerFilterItem extends FilterItemComponent {

	public ProducerFilterItem(WebDriver driver) {
		super(driver);
	}

}
